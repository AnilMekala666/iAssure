import React, { useState } from 'react';
import { DataGrid } from '@mui/x-data-grid';
import SearchIcon from '@mui/icons-material/Search';
import Asgardia from '../assets/images/Assessment/Asgardia.png';
import { Modal, Box, Typography, Button, CardContent, Grid } from '@mui/material';
import Card from '@mui/material/Card';  
import Group1 from '../assets/images/Assessment/Group1.png'
import Group2 from '../assets/images/Assessment/Group2.png'
import Group3 from '../assets/images/Assessment/Group3.png'

import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';


function Assessment() {
    const [open, setOpen] = useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);
    // Table
    const columns = [
        { field: 'id', headerName: 'ID', width: 70 },
        { field: 'assessment', headerName: 'Assessment', width: 300, renderCell: (params) => ( // Customize the cell renderer
            <div style={{ display: 'flex', alignItems: 'center' }}>
                <img src={Asgardia} alt="Warehouse" style={{ marginRight: '8px', width: '30px', height: '30px' }} /> {/* Display the image */}
                <span>{params.value}</span> {/* Display the assessment name */}
            </div>
        )},
        { field: 'lastpublished', headerName: 'Last Published', width: 130 },
        {
            field: 'lastmodified',
            headerName: 'Last modified',
            width: 130,
        },
        {
            field: 'scheduled',
            headerName: 'Scheduled',
            width: 100,
        },
        {
            field: 'access',
            headerName: 'Access',
            type: 'number',
            width: 130,
        },
        {
            field: 'startassessment',
            headerName: '',
            type: '',
            width: 130,
        },
        {
            field: 'action',
            headerName: '',
            type: '',
            width: 130,
        },

    ];

    const rows = [
        { id: 1, assessment: 'Warehouse Safety Checklist', lastpublished: '7 days ago', lastmodified: '7 days ago', scheduled:'All users', startassessment:'Start Assessment' },
        { id: 2, assessment: 'Warehouse Safety Checklist', lastpublished: '7 days ago', lastmodified: '7 days ago', scheduled:'All users', startassessment:'Start Assessment' },
    ];

    return (
        <div style={{ marginTop: "40px" }}>
            <div className='right-cont ms-4 gap-3 me-4'>
                <div className='card'>
                    <div className='body-cont'>
                        <div className='bodycont-in d-flex bd-highlight border-0 mb-0'>
                            <h3 className='flex-grow-1 bd-highlight'>Recent Assessments</h3>
                            <LocalizationProvider dateAdapter={AdapterDayjs} className="d-flex bd-highlight pt-0">
                                <DemoContainer components={['DatePicker']}>
                                    <DatePicker label="Date Filter" className='date-block'/>
                                </DemoContainer>
                            </LocalizationProvider>
                            <button className='btn btn-edit bd-highlight me-2 ms-2'><SearchIcon /></button>
                            <button className='btn btn-danger btn-orange d-flex bd-highlight' onClick={handleOpen}>New Assessments</button>
                        </div>
                        <div style={{ height: 400, width: '100%'}}>
                            <DataGrid
                                sx={{
                                    '.MuiDataGrid-columnHeaderTitle': { 
                                       fontWeight: '400 !important',
                                       fontSize: '16px'
                                    },
                                    '.MuiDataGrid-cellContent':{
                                        fontWeight: '500 !important',
                                       fontSize: '16px'
                                    }
                                  }}
                                rows={rows}
                                columns={columns}
                                initialState={{
                                    pagination: {
                                        paginationModel: { page: 0, pageSize: 5 },
                                    },
                                }}
                                pageSizeOptions={[5, 10]}
                                checkboxSelection
                            />

<Modal
                                open={open}
                                onClose={handleClose}
                                aria-labelledby="modal-modal-title"
                                aria-describedby="modal-modal-description"
                            >
                                <Box sx={{
                                    position: 'absolute',
                                    top: '50%',
                                    left: '50%',
                                    borderRadius:'32px',
                                    transform: 'translate(-50%, -50%)',
                                    bgcolor: 'background.paper',
                                    boxShadow: 24,
                                    p: 4,
                                    maxWidth: 1000,
                                    width: '100%',
                                }}>
                                    <Typography id="modal-modal-title" variant="h6" component="h2"
                                        sx={{
                                            fontSize:'32px',
                                            fontWeight:'500',
                                            textAlign:'center',
                                            color:'#515151'
                                        }}
                                    >
                                        Create a new assessment
                                    </Typography>
                                    <Typography id="modal-modal-description" sx={{ mt: 2 }}>
                                        <Grid container spacing={2}> {/* Grid container */}
                                            <Grid item xs={4} > {/* Grid item for each card, xs={4} means it takes 4/12 of the container width */}
                                                <Card className='border rounded shadow-none text-center pt-4 pb-4' sx={{height:'235px'}}>
                                                    <CardContent>
                                                        <Typography variant="h6" component="div" className='mb-4'>
                                                            <img src={Group1} alt="Group1" />
                                                        </Typography>
                                                        <Typography variant="body2" sx={{fontSize:'16px'}}>
                                                            Simple assessment
                                                        </Typography>
                                                    </CardContent>
                                                </Card>
                                            </Grid>
                                            <Grid item xs={4}> {/* Second card */}
                                                <Card className='border rounded shadow-none text-center pt-4 pb-4' sx={{height:'235px'}}>
                                                    <CardContent>
                                                        <Typography variant="h6" component="div" className='mb-4'>
                                                            <img src={Group2} alt="Group2" />
                                                        </Typography>
                                                        <Typography variant="body2" sx={{fontSize:'16px'}}>
                                                            Document assessment
                                                        </Typography>
                                                    </CardContent>
                                                </Card>
                                            </Grid>
                                            <Grid item xs={4}> {/* Third card */}
                                                <Card className='border rounded shadow-none text-center pt-4 pb-4' sx={{height:'235px'}}>
                                                    <CardContent>
                                                        <Typography variant="h6" component="div" className='mb-4'>
                                                            <img src={Group3} alt="Group3
                                                            " />
                                                        </Typography>
                                                        <Typography variant="body2" sx={{fontSize:'16px'}}>
                                                            Inventory assessment
                                                        </Typography>
                                                    </CardContent>
                                                </Card>
                                            </Grid>
                                        </Grid>
                                    </Typography>
                                    <Button onClick={handleClose} sx={{ mt: 2 }}>
                                        Close
                                    </Button>
                                </Box>
                            </Modal>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Assessment