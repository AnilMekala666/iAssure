import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './Component/Header';
import Sidebar from './Component/sidebar';
import Home from './pages/Home';
import Assessment from './pages/Assessment';
import AssessmentDetails from './pages/AssessmentDetails';
import Schedule from './pages/Schedule';

function App() {
  return (
    <Router>
      <div>
        <Header />
        <div>
          <Sidebar />
          <Routes>
            {/* <Route path="/" element={<Home />} /> */}
            <Route path="/assessment" element={<Assessment />} />
            <Route path="/schedule" element={<Schedule />} />
            {/* <Route path='/AssessmentDetails' element={<AssessmentDetails/>}/> */}
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;
